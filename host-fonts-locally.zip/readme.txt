=== Host Fonts Locally ===
Contributors: Robert Palmer
Tags: Divi, performance, fonts, Google Fonts, cache, optimization, GDPR Regulation
Requires at least: 3.0.1
Tested up to: 6.8
Stable tag: 1.8.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Divi: Host Google Fonts from the local cache.

== Description ==
Host Google Fonts Locally - for Divi & other page builders.

== Installation ==
1. Upload the plugin and activate.
2. Purge any minify/CDN caches.
3. Load pages using fonts to populate the cache.

== Frequently Asked Questions ==
= Icons missing? =
This plugin intentionally skips icon CSS. If icons were previously rewritten by another tool, purge its cache and CDN.

= Where is the cache? =
/wp-content/uploads/sgfc-cache/` (css + fonts).

= Debugging =
Add `define('SGFC_DEBUG', true);` in wp-config.php to write to `debug.log`.

== Changelog ==
= 1.8.0 =
* Release Version